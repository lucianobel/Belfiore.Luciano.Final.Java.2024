package Main;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;
import view.VehiculoView;

public class main extends Application {

    @Override
    public void start(Stage stage) {
        new VehiculoView(stage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
