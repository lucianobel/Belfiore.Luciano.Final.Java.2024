package pkgfinal;

public enum TipoVehiculo {
    AUTO,
    CAMIONETA,
    MOTO
}
