package pkgfinal;

public interface ICalculable {
    double calcularCostoEstadia(int horas);
}

