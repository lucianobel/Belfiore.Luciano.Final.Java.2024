package pkgfinal;

import model.Vehiculo;
import model.Auto;
import model.Camioneta;
import model.Moto;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Gestor<T extends Vehiculo> implements ICrud<T>, Serializable {

    private List<T> lista;
    private transient ObservableList<T> observableLista;

    public Gestor() {
        lista = new ArrayList<>();
        observableLista = FXCollections.observableArrayList(lista);
    }

    // ================= CRUD =================
    @Override
    public boolean crear(T elemento) {
        if (leer(elemento.getPatente()) == null) {
            lista.add(elemento);
            observableLista.add(elemento);
            return true;
        }
        return false;
    }

    @Override
    public T leer(String patente) {
        for (T elemento : lista) {
            if (elemento.getPatente().equalsIgnoreCase(patente)) return elemento;
        }
        return null;
    }

    @Override
    public boolean actualizar(T elemento) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getPatente().equalsIgnoreCase(elemento.getPatente())) {
                lista.set(i, elemento);
                observableLista.set(i, elemento);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean eliminar(String patente) {
        T elemento = leer(patente);
        if (elemento != null) {
            lista.remove(elemento);
            observableLista.remove(elemento);
            return true;
        }
        return false;
    }

    // ================= LISTAS =================
    public List<T> getLista() {
        return lista;
    }

    public ObservableList<T> getObservableList() {
        observableLista.setAll(lista); // Sincroniza antes de devolver
        return observableLista;
    }

    // ================= GUARDADO =================
    public void guardarBinario(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        }
    }

    public void cargarBinario(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            lista = (List<T>) ois.readObject();
            if (observableLista == null) observableLista = FXCollections.observableArrayList();
            observableLista.setAll(lista);
        }
    }

    public void guardarCSV(String ruta) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            bw.write("Patente;Marca;Tipo");
            bw.newLine();
            for (T v : lista) {
                bw.write(v.getPatente() + ";" + v.getMarca() + ";" + v.getTipoVehiculo());
                bw.newLine();
            }
        }
    }

    public void cargarCSV(String ruta) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            lista.clear();
            br.readLine();
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";");
                String patente = datos[0];
                String marca = datos[1];
                TipoVehiculo tipo = TipoVehiculo.valueOf(datos[2]);

                Vehiculo v = switch (tipo) {
                    case AUTO -> new Auto(patente, marca, 4, Combustible.NAFTA);
                    case CAMIONETA -> new Camioneta(patente, marca, 2, Combustible.DIESEL);
                    case MOTO -> new Moto(patente, marca, Combustible.NAFTA);
                };

                lista.add((T) v);
            }
            if (observableLista == null) observableLista = FXCollections.observableArrayList();
            observableLista.setAll(lista);
        }
    }

    public void guardarJSON(String ruta) throws IOException {
        Gson gson = new Gson();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            gson.toJson(lista, bw);
        }
    }

    public void cargarJSON(String ruta, TypeToken<List<T>> tipo) throws IOException {
        Gson gson = new Gson();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            lista = gson.fromJson(br, tipo.getType());
        }
        if (observableLista == null) observableLista = FXCollections.observableArrayList();
        observableLista.setAll(lista);
    }
}