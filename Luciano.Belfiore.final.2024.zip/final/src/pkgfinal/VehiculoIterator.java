package pkgfinal;

import java.util.Iterator;
import java.util.List;

public class VehiculoIterator<T> implements Iterator<T> {

    private List<T> lista;
    private int posicion;

    public VehiculoIterator(List<T> lista) {
        this.lista = lista;
        this.posicion = 0;
    }

    @Override
    public boolean hasNext() {
        return posicion < lista.size();
    }

    @Override
    public T next() {
        return lista.get(posicion++);
    }
}
