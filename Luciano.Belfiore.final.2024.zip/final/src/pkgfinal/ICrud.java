package pkgfinal;

public interface ICrud<T> {

    boolean crear(T elemento);

    T leer(String identificador);

    boolean actualizar(T elemento);

    boolean eliminar(String identificador);
}
