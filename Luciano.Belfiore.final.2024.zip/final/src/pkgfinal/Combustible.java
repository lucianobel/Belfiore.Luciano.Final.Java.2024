package pkgfinal;

public enum Combustible {
    NAFTA,
    DIESEL,
    ELECTRICO
}
