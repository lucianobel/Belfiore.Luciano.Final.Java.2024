package model;

import java.io.Serializable;
import pkgfinal.Combustible;
import pkgfinal.ICalculable;
import pkgfinal.TipoVehiculo;

public class Moto extends Vehiculo implements ICalculable, Serializable {

    private Combustible combustible;

    public Moto(String patente, String marca, Combustible combustible) {
        super(patente, marca, TipoVehiculo.MOTO);
        this.combustible = combustible;
    }

    public Combustible getCombustible() {
        return combustible;
    }

    public void setCombustible(Combustible combustible) {
        this.combustible = combustible;
    }

    @Override
    public double calcularCostoEstadia(int horas) {
        return horas * 300;
    }
}
