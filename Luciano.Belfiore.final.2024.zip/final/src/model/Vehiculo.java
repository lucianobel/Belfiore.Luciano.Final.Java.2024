package model;

import java.io.Serializable;
import pkgfinal.TipoVehiculo;

public abstract class Vehiculo implements Comparable<Vehiculo>, Serializable {

    protected String patente;
    protected String marca;
    protected TipoVehiculo tipoVehiculo;
    private double precioHora;
    private int horas;
    

    // Constructor con todos los atributos
    public Vehiculo(String patente, String marca, TipoVehiculo tipoVehiculo) {
        this.patente = patente;
        this.marca = marca;
        this.tipoVehiculo = tipoVehiculo;
    }

    // Constructor con un parámetro menos
    public Vehiculo(String patente, String marca) {
        this(patente, marca, TipoVehiculo.AUTO);
    }

    // Constructor a elección
    public Vehiculo(String patente) {
        this(patente, "Desconocida", TipoVehiculo.AUTO);
    }

    // Comportamientos comunes
    public void ingresar() {
        System.out.println("El vehículo con patente " + patente + " ingresó al estacionamiento.");
    }

    public void salir() {
        System.out.println("El vehículo con patente " + patente + " salió del estacionamiento.");
    }

    public String obtenerDatos() {
        return "Patente: " + patente + " | Marca: " + marca + " | Tipo: " + tipoVehiculo;
    }

    // Getters y Setters
    
    public double getPrecioHora() {
        return precioHora;
    }

    public void setPrecioHora(double precioHora) {
        this.precioHora = precioHora;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }
    
    public String getPatente() {
        return patente;
    }
    
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public TipoVehiculo getTipoVehiculo() {
        return tipoVehiculo;
    }
    
    @Override
    public int compareTo(Vehiculo otro) {
        return this.patente.compareToIgnoreCase(otro.patente);
    }
    
    @Override
    public String toString() {
        return "Patente: " + patente +
               " | Marca: " + marca +
               " | Tipo: " + tipoVehiculo;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Vehiculo)) return false;
        Vehiculo v = (Vehiculo) obj;
        return patente.equalsIgnoreCase(v.patente);
    }
}

