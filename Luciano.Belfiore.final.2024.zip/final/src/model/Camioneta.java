package model;

import java.io.Serializable;
import pkgfinal.Combustible;
import pkgfinal.ICalculable;
import pkgfinal.TipoVehiculo;

public class Camioneta extends Vehiculo implements ICalculable, Serializable {

    private int cantidadPuertas;
    private Combustible combustible;

    public Camioneta(String patente, String marca, int puertas, Combustible combustible) {
        super(patente, marca, TipoVehiculo.CAMIONETA);
        this.cantidadPuertas = puertas;
        this.combustible = combustible;
    }

    public int getPuertas() {
        return cantidadPuertas;
    }

    public Combustible getCombustible() {
        return combustible;
    }

    public void setCombustible(Combustible combustible) {
        this.combustible = combustible;
    }

    @Override
    public double calcularCostoEstadia(int horas) {
        return horas * 800;
    }
}