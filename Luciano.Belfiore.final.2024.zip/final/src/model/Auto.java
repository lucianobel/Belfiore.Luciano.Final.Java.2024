package model;

import java.io.Serializable;
import pkgfinal.Combustible;
import pkgfinal.ICalculable;
import pkgfinal.TipoVehiculo;

public class Auto extends Vehiculo implements ICalculable, Serializable {

    private int cantidadPuertas;
    private Combustible combustible;

    public Auto(String patente, String marca, int puertas, Combustible combustible) {
        super(patente, marca, TipoVehiculo.AUTO);
        this.cantidadPuertas = puertas;
        this.combustible = combustible;
    }

    public int getPuertas() {
        return cantidadPuertas;
    }

    public Combustible getCombustible() {
        return combustible;
    }

    public void setCombustible(Combustible combustible) {
        this.combustible = combustible;
    }

    @Override
    public double calcularCostoEstadia(int horas) {
        return horas * 500;
    }
}