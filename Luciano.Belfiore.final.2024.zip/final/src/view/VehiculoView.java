package view;

import controller.VehiculoController;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import pkgfinal.TipoVehiculo;
import model.*;
import pkgfinal.Combustible;
import pkgfinal.ICalculable;
import java.io.IOException;


public class VehiculoView {

    private VehiculoController controller;
    private TableView<Vehiculo> tabla;

    public VehiculoView(Stage stage) {

        controller = new VehiculoController();
        tabla = new TableView<>();

        // ================= TABLA =================
        TableColumn<Vehiculo, String> colPatente = new TableColumn<>("Patente");
        colPatente.setCellValueFactory(new PropertyValueFactory<>("patente"));

        TableColumn<Vehiculo, String> colMarca = new TableColumn<>("Marca");
        colMarca.setCellValueFactory(new PropertyValueFactory<>("marca"));

        TableColumn<Vehiculo, TipoVehiculo> colTipo = new TableColumn<>("Tipo");
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipoVehiculo"));

        TableColumn<Vehiculo, Combustible> colCombustible = new TableColumn<>("Combustible");
        colCombustible.setCellValueFactory(new PropertyValueFactory<>("combustible"));

        TableColumn<Vehiculo, Integer> colPuertas = new TableColumn<>("Puertas");
        colPuertas.setCellValueFactory(cell -> {
            Vehiculo v = cell.getValue();
            if (v instanceof Auto a) return new SimpleIntegerProperty(a.getPuertas()).asObject();
            if (v instanceof Camioneta c) return new SimpleIntegerProperty(c.getPuertas()).asObject();
            return new SimpleIntegerProperty(0).asObject();
        });

        TableColumn<Vehiculo, Double> colCosto = new TableColumn<>("Costo Total");
        colCosto.setCellValueFactory(cell ->
                new SimpleDoubleProperty(
                        ((ICalculable) cell.getValue())
                                .calcularCostoEstadia(cell.getValue().getHoras())
                ).asObject()
        );

        tabla.getColumns().addAll(colPatente, colMarca, colTipo, colCombustible, colPuertas, colCosto);

        // ================= CAMPOS =================
        TextField txtPatente = new TextField(); txtPatente.setPromptText("Patente");
        TextField txtMarca = new TextField(); txtMarca.setPromptText("Marca");
        TextField txtPuertas = new TextField(); txtPuertas.setPromptText("Puertas");
        TextField txtHoras = new TextField(); txtHoras.setPromptText("Horas");

        ComboBox<TipoVehiculo> cbTipo = new ComboBox<>();
        cbTipo.getItems().addAll(TipoVehiculo.values());
        cbTipo.setValue(TipoVehiculo.AUTO);

        ComboBox<Combustible> cbCombustible = new ComboBox<>();
        cbCombustible.getItems().addAll(Combustible.values());
        cbCombustible.setValue(Combustible.NAFTA);

        // 🔒 Puertas solo para AUTO / CAMIONETA
        cbTipo.valueProperty().addListener((obs, old, tipo) -> {
            if (tipo == TipoVehiculo.MOTO) {
                txtPuertas.clear();
                txtPuertas.setDisable(true);
            } else {
                txtPuertas.setDisable(false);
            }
        });

        // ================= BOTONES =================
        Button btnAgregar = new Button("Agregar");
        Button btnActualizar = new Button("Actualizar");
        Button btnEliminar = new Button("Eliminar");

        btnAgregar.setOnAction(e -> {
            try {
                String patente = txtPatente.getText().trim();
                String marca = txtMarca.getText().trim();
                TipoVehiculo tipo = cbTipo.getValue();
                Combustible comb = cbCombustible.getValue();

                if (patente.isEmpty() || marca.isEmpty()) {
                    mostrarAlerta("Error", "La patente y marca son obligatorias");
                    return;
                }

                double precio = switch (tipo) {
                    case AUTO -> 500;
                    case CAMIONETA -> 800;
                    case MOTO -> 300;
                };

                int horas = Integer.parseInt(txtHoras.getText().trim());

                Vehiculo v = null;
                switch (tipo) {
                    case AUTO -> v = new Auto(patente, marca, Integer.parseInt(txtPuertas.getText().trim()), comb);
                    case CAMIONETA -> v = new Camioneta(patente, marca, Integer.parseInt(txtPuertas.getText().trim()), comb);
                    case MOTO -> v = new Moto(patente, marca, comb);
                }

                v.setPrecioHora(precio);
                v.setHoras(horas);

                if (controller.getGestor().crear(v)) {
                    limpiarCampos(txtPatente, txtMarca, txtPuertas, txtHoras);
                } else {
                    mostrarAlerta("Error", "Ya existe un vehículo con esa patente");
                }
            } catch (NumberFormatException ex) {
                mostrarAlerta("Error", "Por favor ingresa números válidos");
            }
        });

        btnActualizar.setOnAction(e -> {
            Vehiculo v = tabla.getSelectionModel().getSelectedItem();
            if (v != null) {
                try {
                    if (!txtMarca.getText().trim().isEmpty()) v.setMarca(txtMarca.getText().trim());
                    if (!txtHoras.getText().trim().isEmpty()) v.setHoras(Integer.parseInt(txtHoras.getText().trim()));
                    Combustible comb = cbCombustible.getValue();
                    if (comb != null) {
                        if (v instanceof Auto) ((Auto)v).setCombustible(comb);
                        if (v instanceof Camioneta) ((Camioneta)v).setCombustible(comb);
                        if (v instanceof Moto) ((Moto)v).setCombustible(comb);
                    }
                } catch (NumberFormatException ex) {
                    mostrarAlerta("Error", "Por favor ingresa números válidos");
                }
            } else mostrarAlerta("Error", "Selecciona un vehículo");
        });

        btnEliminar.setOnAction(e -> {
            Vehiculo v = tabla.getSelectionModel().getSelectedItem();
            if (v != null) controller.getGestor().eliminar(v.getPatente());
            else mostrarAlerta("Error", "Selecciona un vehículo");
        });

        // ================= BOTONES GUARDAR / CARGAR =================
        Button btnGuardarTodo = new Button("Guardar Todo");
        Button btnCargar = new Button("Cargar");


        btnGuardarTodo.setOnAction(e -> {
            try {
                controller.getGestor().guardarBinario("datos/vehiculos.dat");
                controller.getGestor().guardarCSV("datos/vehiculos.csv");
                controller.getGestor().guardarJSON("datos/vehiculos.json");
                mostrarAlerta("Éxito", "Datos guardados correctamente");
            } catch (IOException ex) {
                mostrarAlerta("Error", "No se pudieron guardar los datos:\n" + ex.getMessage());
            }
            
        });

        btnCargar.setOnAction(e -> {
            try {
                controller.getGestor().cargarCSV("datos/vehiculos.csv");
                mostrarAlerta("Éxito", "Datos cargados");
            } catch (IOException ex) {
                mostrarAlerta("Error", "No se pudo cargar:\n" + ex.getMessage());
            }
        });

        // ================= FILTRO =================
        TextField txtFiltro = new TextField(); txtFiltro.setPromptText("Filtrar por marca");
        Button btnFiltrar = new Button("Filtrar");
        Button btnLimpiar = new Button("Limpiar");

        FilteredList<Vehiculo> filtrados = new FilteredList<>(controller.getGestor().getObservableList(), v -> true);
        SortedList<Vehiculo> ordenados = new SortedList<>(filtrados);
        ordenados.comparatorProperty().bind(tabla.comparatorProperty());
        tabla.setItems(ordenados);

        btnFiltrar.setOnAction(e -> {
            String texto = txtFiltro.getText().toLowerCase();
            filtrados.setPredicate(v -> texto.isEmpty() || v.getMarca().toLowerCase().contains(texto));
        });

        btnLimpiar.setOnAction(e -> {
            txtFiltro.clear();
            filtrados.setPredicate(v -> true);
        });

        // ================= CONTADORES =================
        Label lblResultado = new Label("");
        Button btnAutos = new Button("Autos");
        Button btnMotos = new Button("Motos");
        Button btnCamionetas = new Button("Camionetas");

        btnAutos.setOnAction(e ->
                lblResultado.setText("Autos: " +
                        controller.getGestor().getLista().stream().filter(v -> v.getTipoVehiculo() == TipoVehiculo.AUTO).count()));

        btnMotos.setOnAction(e ->
                lblResultado.setText("Motos: " +
                        controller.getGestor().getLista().stream().filter(v -> v.getTipoVehiculo() == TipoVehiculo.MOTO).count()));

        btnCamionetas.setOnAction(e ->
                lblResultado.setText("Camionetas: " +
                        controller.getGestor().getLista().stream().filter(v -> v.getTipoVehiculo() == TipoVehiculo.CAMIONETA).count()));

        // ================= LAYOUT =================
        HBox filaCampos1 = new HBox(10, txtPatente, txtMarca, cbTipo);
        HBox filaCampos2 = new HBox(10, txtPuertas, txtHoras, cbCombustible);
        HBox filaBotones = new HBox(10, btnAgregar, btnActualizar, btnEliminar);
        HBox filaGuardarCargar = new HBox(10, btnGuardarTodo, btnCargar);
        HBox filaFiltro = new HBox(10, txtFiltro, btnFiltrar, btnLimpiar);
        HBox filaFuncional = new HBox(10, btnAutos, btnMotos, btnCamionetas, lblResultado);

        VBox panelIzq = new VBox(10, filaCampos1, filaCampos2, filaBotones, filaFiltro, filaFuncional, filaGuardarCargar);
        panelIzq.setPadding(new Insets(10));

        BorderPane root = new BorderPane();
        root.setLeft(panelIzq);
        root.setCenter(tabla);

        stage.setScene(new Scene(root, 1050, 450));
        stage.setTitle("Gestión de Vehículos");
        stage.show();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos(TextField... campos) {
        for (TextField campo : campos) campo.clear();
    }
}
