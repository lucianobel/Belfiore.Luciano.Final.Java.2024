package controller;

import pkgfinal.Gestor;
import model.Vehiculo;

public class VehiculoController {

    private Gestor<Vehiculo> gestor;

    public VehiculoController() {
        gestor = new Gestor<>();
    }

    public Gestor<Vehiculo> getGestor() {
        return gestor;
    }
}
